# -*- coding: utf-8 -*-
from pathlib import Path
import time
import json
import requests
import shutil

############################
directory_input = "/root/Documentos/IoT_ARM/etapa_1_virustotal_api/benign/benign"
path_input = Path(directory_input)
dir_input = Path(directory_input)

directory_output = "/root/Documentos/IoT_ARM/cuckoobox_relatorio/js/benign"
path_output = Path(directory_output)
dir_output = Path(directory_output)

############################


for file in dir_input.iterdir():
    print('===========================================')
    name = file.name.replace('.json','')
    file_exist = dir_output.joinpath(name + '.json').exists()#correspondencia no VirusTotal

    print(name)
    print("File: ", file.name)

    if file_exist == 0: 
        print('-------------------------------------------')
        src = directory_input + '/' + name
        dst = directory_input + '_excedentes/' + name
        print(src)
        print(dst)
        shutil.move(src, dst)
		
        src = directory_input + '/virustotal/' + name + '.json'
        dst = directory_input + '/virustotal_excedentes/' + name + '.json'
        print(src)
        print(dst)			
        shutil.move(src, dst)
		
        src = directory_input + '/cuckoobox/' + name + '.json'
        dst = directory_input + '/cuckoobox_excedentes/' + name + '.json'
        print(src)
        print(dst)			
        shutil.move(src, dst)



