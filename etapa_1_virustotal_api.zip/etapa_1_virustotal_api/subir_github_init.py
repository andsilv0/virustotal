import json
import requests
import time
import shutil
import os
import os.path

###########################################
version = 'version 1.0'
#antivirus = 'template'
os.system('git config --global user.name "REFADE"')
os.system('git config --global user.email "smll@ecomp.poli.br"')
os.system('git config --global credential.helper store')
os.system('git clone --no-checkout https://github.com/refade/'+antivirus)

###########################################



